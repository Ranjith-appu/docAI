import { useState, useEffect } from "react";
import Navbar from "./components/Navbar.tsx";
import LandingPage from "./components/LandingPage.tsx";
import FileUpload from "./components/FileUpload.tsx";
import ReportDashboard from "./components/ReportDashboard.tsx";
import UserDashboard from "./components/UserDashboard.tsx";
import AdminPanel from "./components/AdminPanel.tsx";
import VoiceAssistant from "./components/VoiceAssistant.tsx";
import { User, AnalysisReport } from "./types.ts";
import { Sparkles, CheckCircle, ShieldCheck } from "lucide-react";

// Safe localStorage wrapper to prevent crash if iframe permissions block storage access
const safeStorage = {
  memo: {} as Record<string, string>,
  getItem(key: string): string | null {
    try {
      return window.localStorage.getItem(key);
    } catch (e) {
      return this.memo[key] || null;
    }
  },
  setItem(key: string, value: string): void {
    try {
      window.localStorage.setItem(key, value);
    } catch (e) {
      this.memo[key] = value;
    }
  },
  removeItem(key: string): void {
    try {
      window.localStorage.removeItem(key);
    } catch (e) {
      delete this.memo[key];
    }
  }
};

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [reports, setReports] = useState<AnalysisReport[]>([]);
  const [activeReport, setActiveReport] = useState<AnalysisReport | null>(null);
  const [activeView, setActiveView] = useState<'main' | 'dashboard' | 'admin'>('main');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisError, setAnalysisError] = useState<string | null>(null);

  // Initialize and load session from localStorage
  useEffect(() => {
    const savedUser = safeStorage.getItem("authentiai_user");
    if (savedUser) {
      try {
        const parsedUser = JSON.parse(savedUser);
        setUser(parsedUser);
        fetchUserHistory(parsedUser.id);
      } catch (err) {
        console.error("Failed to restore session", err);
        safeStorage.removeItem("authentiai_user");
      }
    }
  }, []);

  // Fetch verified user scan histories
  const fetchUserHistory = async (userId: string) => {
    try {
      const res = await fetch(`/api/reports?userId=${userId}`);
      if (res.ok) {
        const data = await res.json();
        setReports(data);
      }
    } catch (error) {
      console.error("Failed to load user document history:", error);
    }
  };

  // Login handler
  const handleLogin = async (email: string) => {
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email })
      });
      if (res.ok) {
        const data = await res.json();
        setUser(data.user);
        safeStorage.setItem("authentiai_user", JSON.stringify(data.user));
        fetchUserHistory(data.user.id);
        setActiveView('main');
        setActiveReport(null);
      }
    } catch (e) {
      console.error("Login authorization failed", e);
    }
  };

  // Logout handler
  const handleLogout = () => {
    safeStorage.removeItem("authentiai_user");
    setUser(null);
    setReports([]);
    setActiveReport(null);
    setActiveView('main');
  };

  // Update profile name
  const handleUpdateName = async (name: string) => {
    if (!user) return;
    try {
      const res = await fetch("/api/user/profile", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId: user.id, name })
      });
      if (res.ok) {
        const data = await res.json();
        setUser(data.user);
        safeStorage.setItem("authentiai_user", JSON.stringify(data.user));
      }
    } catch (e) {
      console.error("Profile name update failed", e);
    }
  };

  // Toggle Plan directly
  const handleTogglePlan = async () => {
    if (!user) return;
    try {
      const res = await fetch("/api/user/toggle-plan", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId: user.id })
      });
      if (res.ok) {
        const data = await res.json();
        setUser(data.user);
        safeStorage.setItem("authentiai_user", JSON.stringify(data.user));
      }
    } catch (e) {
      console.error("Failed to change user plan", e);
    }
  };

  // Start Analyzing uploaded file
  const handleAnalyzeFile = async (file: File) => {
    if (!user) return;
    setIsAnalyzing(true);
    setAnalysisError(null);

    const isBinary = file.type.toLowerCase().includes("pdf") || 
                     file.type.toLowerCase().startsWith("image/") || 
                     file.type.toLowerCase().startsWith("audio/") ||
                     ["png", "jpg", "jpeg", "webp", "gif", "mp3", "wav", "ogg", "mpeg", "m4a", "pdf"].some(ext => file.name.toLowerCase().endsWith("." + ext));

    try {
      const reader = new FileReader();

      if (isBinary) {
        // Binary files strategy (PDFs, images, audios) using base64 stream encoding
        reader.onload = async () => {
          try {
            const dataUrl = reader.result as string;
            const base64Data = dataUrl.split(",")[1] || "";

            const payload = {
              userId: user.id,
              fileName: file.name,
              fileType: file.type || "application/octet-stream",
              fileSize: file.size,
              base64Data
            };

            await sendAnalysisPayload(payload);
          } catch (e: any) {
            setAnalysisError(e.message || "Failed to compile file bytes.");
            setIsAnalyzing(false);
          }
        };
        reader.readAsDataURL(file);
      } else {
        // Code and plain-text strategy: Read contents as String text
        reader.onload = async () => {
          try {
            const textContent = reader.result as string;
            const payload = {
              userId: user.id,
              fileName: file.name,
              fileType: file.type || "text/plain",
              fileSize: file.size,
              rawText: textContent
            };

            await sendAnalysisPayload(payload);
          } catch (e: any) {
            setAnalysisError(e.message || "Failed to read plain content structure.");
            setIsAnalyzing(false);
          }
        };
        reader.readAsText(file);
      }
    } catch (error: any) {
      setAnalysisError(error.message || "File reader failed completely.");
      setIsAnalyzing(false);
    }
  };

  const sendAnalysisPayload = async (payload: any) => {
    if (!user) return;
    try {
      const response = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "Linguistic classifier network error.");
      }

      const report: AnalysisReport = await response.json();
      
      // Update reports list
      setReports(prev => [report, ...prev]);
      setActiveReport(report);

      // Refresh user daily limits (mirrored from server)
      const updatedUser = { ...user, analysesToday: user.analysesToday + 1 };
      setUser(updatedUser);
      safeStorage.setItem("authentiai_user", JSON.stringify(updatedUser));

    } catch (error: any) {
      setAnalysisError(error.message || "Linguistic classification failed. Please verify files are intact.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleDeleteReport = async (reportId: string) => {
    if (!user) return;
    try {
      const res = await fetch(`/api/reports/${reportId}/delete`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId: user.id })
      });
      if (res.ok) {
        setReports(prev => prev.filter(r => r.id !== reportId));
        if (activeReport?.id === reportId) {
          setActiveReport(null);
        }
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Navigations routing
  const handleNavigate = (view: 'main' | 'dashboard' | 'admin') => {
    setActiveView(view);
    setActiveReport(null);
  };

  const handleSelectReport = (report: AnalysisReport) => {
    setActiveReport(report);
    setActiveView('main');
  };

  // Logged-out state renders Landing Page
  if (!user) {
    return <LandingPage onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen bg-gray-950 text-white font-sans selection:bg-cyan-500/30 selection:text-white">
      <Navbar 
        user={user} 
        onLogout={handleLogout} 
        onNavigate={handleNavigate}
        activeView={activeView}
        onTogglePlan={handleTogglePlan}
      />

      <main className="pb-16 min-h-[calc(100vh-4rem)]">
        {activeReport ? (
          /* Render full statistics results analysis screen */
          <ReportDashboard 
            report={activeReport} 
            onClose={() => setActiveReport(null)} 
          />
        ) : (
          /* Sub-screen selector logic */
          <>
            {activeView === 'main' && (
              <FileUpload 
                user={user}
                onAnalyze={handleAnalyzeFile}
                isAnalyzing={isAnalyzing}
                errorMsg={analysisError}
              />
            )}

            {activeView === 'dashboard' && (
              <UserDashboard 
                user={user}
                reports={reports}
                onSelectReport={handleSelectReport}
                onDeleteReport={handleDeleteReport}
                onTogglePlan={handleTogglePlan}
                onUpdateName={handleUpdateName}
              />
            )}

            {activeView === 'admin' && (
              <AdminPanel 
                onSelectReport={handleSelectReport} 
              />
            )}
          </>
        )}
      </main>

      {/* FLOATING FORENSIC LOUDSPEAKER INTERACTIVE VOICE ASSISTANT */}
      <VoiceAssistant userId={user.id} />
    </div>
  );
}
