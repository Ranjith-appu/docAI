export interface User {
  id: string;
  email: string;
  name: string;
  subscriptionPlan: 'free' | 'premium';
  analysesToday: number;
  lastAnalysisDate: string; // YYYY-MM-DD
  createdAt: string;
  avatarUrl?: string;
}

export interface ReadabilityMetrics {
  complexityScore: number; // 0 to 100
  readabilityLevel: string; // e.g., "Easy", "Medium", "Complex"
  vocabularyDiversity: number; // 0 to 100
  sentenceStructureScore: number; // 0 to 100
}

export interface PatternAnalysis {
  repetitiveness: number; // 0 to 100
  predictabilityScore: number; // 0 to 100
  originalityScore: number; // 0 to 100
  codeStyleIndicators?: string; // only for code files
}

export interface SuspiciousHighlight {
  id: string;
  text: string;
  isSuspicious: boolean;
  score: number; // probability of being AI (0 to 100)
  reason?: string;
}

export interface AnalysisReport {
  id: string;
  userId: string;
  fileName: string;
  fileType: string;
  fileSize: number;
  wordCount: number;
  aiProbability: number; // 0 to 100
  humanProbability: number; // 0 to 100
  confidenceScore: number; // 0 to 100
  riskLevel: 'Low' | 'Moderate' | 'High' | 'Critical';
  detailedExplanation: string;
  readability: ReadabilityMetrics;
  patterns: PatternAnalysis;
  highlights: SuspiciousHighlight[];
  metadata: {
    author?: string;
    createdDate?: string;
    generatorTool?: string;
    entropyLevel?: number;
    [key: string]: any;
  };
  createdAt: string;
}

export interface DashboardMetrics {
  totalScans: number;
  aiDetectedScans: number;
  humanDetectedScans: number;
  averageAIProbability: number;
  scansByPlan: { free: number; premium: number };
}
