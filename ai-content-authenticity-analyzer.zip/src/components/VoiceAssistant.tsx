import React, { useState, useEffect, useRef } from "react";
import { Mic, MicOff, Volume2, VolumeX, Send, X, MessageSquare, Sparkles, Loader2 } from "lucide-react";

interface VoiceAssistantProps {
  userId: string;
}

interface Message {
  sender: "user" | "assistant";
  text: string;
}

export default function VoiceAssistant({ userId }: VoiceAssistantProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      sender: "assistant",
      text: "Hello! I am your AuthentiAI Voice Assistant. Ask me how to find AI artifacts in images, audio clips, or documents!"
    }
  ]);
  const [inputText, setInputText] = useState("");
  const [isListening, setIsListening] = useState(false);
  const [isTTSMuted, setIsTTSMuted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);
  
  // Speech Recognition API reference
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    // Scroll to bottom on updates
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isOpen]);

  // Handle Speech Recognition setup of Web Speech API
  useEffect(() => {
    try {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      if (SpeechRecognition) {
        const rec = new SpeechRecognition();
        rec.continuous = false;
        rec.interimResults = false;
        rec.lang = "en-US";

        rec.onstart = () => {
          setIsListening(true);
        };

        rec.onresult = (event: any) => {
          const transcript = event.results[0][0].transcript ?? "";
          if (transcript) {
            handleSendMessage(transcript);
          }
        };

        rec.onerror = (err: any) => {
          console.error("Speech Recognition error:", err);
          setIsListening(false);
        };

        rec.onend = () => {
          setIsListening(false);
        };

        recognitionRef.current = rec;
      }
    } catch (e) {
      console.warn("SpeechRecognition construction failed or was restricted in iframe context:", e);
      recognitionRef.current = null;
    }
  }, []);

  // Monitor SpeechSynthesis state to update speaking wave animations
  useEffect(() => {
    const interval = setInterval(() => {
      try {
        if (typeof window !== "undefined" && "speechSynthesis" in window) {
          setIsSpeaking(window.speechSynthesis.speaking);
        }
      } catch (e) {
        // Safe bypass
      }
    }, 250);
    return () => clearInterval(interval);
  }, []);

  const toggleListen = () => {
    if (!recognitionRef.current) {
      setMessages(prev => [
        ...prev,
        {
          sender: "assistant",
          text: "I am sorry, but Speech Recognition is currently blocked or unsupported in this iframe window context. Please type your query in the input field - I am fully responsive via text!"
        }
      ]);
      return;
    }

    if (isListening) {
      try {
        recognitionRef.current.stop();
      } catch (e) {
        console.warn("Failed to stop recognition:", e);
      }
    } else {
      // End speech syntheses first so they don't echo back
      try {
        if (typeof window !== "undefined" && "speechSynthesis" in window) {
          window.speechSynthesis.cancel();
        }
      } catch (e) {
        // ignore
      }
      try {
        recognitionRef.current.start();
      } catch (err) {
        console.error("Start speech failed:", err);
      }
    }
  };

  // Perform browser Text-to-Speech
  const speakText = (text: string) => {
    if (isTTSMuted) return;
    try {
      if (typeof window === "undefined" || !("speechSynthesis" in window)) return;

      window.speechSynthesis.cancel(); // Cancel current speaking before triggering next speech

      const utterance = new SpeechSynthesisUtterance(text);
      
      // Select a pleasant premium default English voice
      const voices = window.speechSynthesis.getVoices();
      if (voices && voices.length > 0) {
        const desiredVoice = voices.find(v => v.lang.startsWith("en") && (v.name.includes("Google") || v.name.includes("Natural") || v.name.includes("Samantha")));
        if (desiredVoice) {
          utterance.voice = desiredVoice;
        }
      }
      
      utterance.rate = 1.05;
      utterance.pitch = 1.0;
      
      utterance.onstart = () => setIsSpeaking(true);
      utterance.onend = () => setIsSpeaking(false);
      utterance.onerror = () => setIsSpeaking(false);

      window.speechSynthesis.speak(utterance);
    } catch (err) {
      console.warn("SpeechSynthesis execution failed or was block due to iframe context permission restrictions:", err);
    }
  };

  const handleSendMessage = async (text: string) => {
    const trimmed = text.trim();
    if (!trimmed) return;

    // Append User Message bubble
    setMessages(prev => [...prev, { sender: "user", text: trimmed }]);
    setInputText("");
    setIsLoading(true);

    try {
      const response = await fetch("/api/assistant/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId, message: trimmed })
      });

      if (!response.ok) {
        throw new Error("Voice network routing failure.");
      }

      const data = await response.json();
      const reply = data.reply || "I encountered an error formulating this dialog response.";

      // Append assistant reply
      setMessages(prev => [...prev, { sender: "assistant", text: reply }]);
      speakText(reply);
    } catch (error) {
      console.error("Assistant chat integration error:", error);
      const errMsg = "I suffered a communication error. Please ensure the local backend server is running.";
      setMessages(prev => [...prev, { sender: "assistant", text: errMsg }]);
      speakText(errMsg);
    } finally {
      setIsLoading(false);
    }
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleSendMessage(inputText);
  };

  return (
    <>
      {/* Floating launcher trigger action button */}
      <button
        onClick={() => setIsOpen(prev => !prev)}
        id="voice-assistant-launcher"
        className="fixed bottom-6 right-6 z-50 flex h-14 w-14 items-center justify-center rounded-full bg-gradient-to-tr from-cyan-500 via-indigo-500 to-indigo-700 text-white shadow-2xl hover:scale-105 transition-all duration-300 group cursor-pointer border border-cyan-400/30"
        title="Open Forensic Voice Assistant"
      >
        {isOpen ? (
          <X className="h-6 w-6" />
        ) : (
          <div className="relative flex items-center justify-center">
            {/* Holographic breathing glow ring elements */}
            <span className="absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-30 animate-ping" />
            <MessageSquare className="h-6 w-6 relative group-hover:rotate-6 transition-transform" />
          </div>
        )}
      </button>

      {/* Slide-out drawer or overlay card panel */}
      {isOpen && (
        <div id="voice-assistant-drawer" className="fixed bottom-24 right-6 z-50 w-80 md:w-96 rounded-2xl border border-gray-800 bg-[#0B0F19] text-white shadow-2xl flex flex-col h-[520px] overflow-hidden transition-all duration-300">
          
          {/* High-tech Title header */}
          <div className="p-4 bg-gradient-to-r from-gray-950 to-gray-900 border-b border-gray-850 flex items-center justify-between">
            <div className="flex items-center space-x-2.5">
              <div className="relative">
                <div className={`h-2.5 w-2.5 rounded-full ${isListening ? "bg-red-500 animate-pulse" : isSpeaking ? "bg-green-400" : "bg-cyan-400"} shadow-lg`} />
                {isListening && (
                  <span className="absolute -top-0.5 -left-0.5 h-3.5 w-3.5 rounded-full border border-red-500 animate-ping opacity-60" />
                )}
              </div>
              <div>
                <h4 className="text-xs font-bold tracking-wider uppercase text-white flex items-center gap-1">
                  <span>AuthentiAI Smart Voice</span>
                  <Sparkles className="h-3 w-3 text-cyan-400 animate-pulse" />
                </h4>
                <p className="text-[9px] text-gray-500 font-mono">FORENSIC TELEMETRY ASSISTANT</p>
              </div>
            </div>

            <div className="flex items-center space-x-1.5">
              {/* Toggle Audio Speech (Mute Button) */}
              <button
                onClick={() => {
                  const val = !isTTSMuted;
                  setIsTTSMuted(val);
                  if (val && typeof window !== "undefined" && "speechSynthesis" in window) {
                    window.speechSynthesis.cancel();
                  }
                }}
                className={`p-1.5 rounded-lg border text-xs cursor-pointer transition ${
                  isTTSMuted 
                    ? "bg-red-950/20 border-red-900/40 text-red-400 hover:bg-red-950/40" 
                    : "bg-gray-900/60 border-gray-800 text-gray-400 hover:text-white"
                }`}
                title={isTTSMuted ? "Unmute Assistant voice" : "Mute Assistant voice"}
              >
                {isTTSMuted ? <VolumeX className="h-3.5 w-3.5" /> : <Volume2 className="h-3.5 w-3.5" />}
              </button>

              <button
                onClick={() => setIsOpen(false)}
                className="p-1.5 rounded-lg bg-gray-900/60 border border-gray-800 text-gray-400 hover:text-white cursor-pointer"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>

          {/* Interactive animated glowing vocalizer orb visualizer component container */}
          <div className="relative h-24 bg-gray-950 flex flex-col items-center justify-center border-b border-gray-850/60 shadow-inner overflow-hidden">
            {/* Futuristic space-dust backdrop dots */}
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(6,182,212,0.06),transparent_65%)]" />

            {/* Glowing wave ripple rings */}
            <div className="flex items-center justify-center space-x-1.5">
              <div className={`h-8 w-1 rounded-full bg-cyan-500 transition-all duration-300 ${isSpeaking ? "animate-bounce h-12" : isListening ? "animate-pulse h-10" : "opacity-40"}`} style={{ animationDelay: "0.1s" }} />
              <div className={`h-11 w-1 bg-indigo-500 transition-all duration-300 ${isSpeaking ? "animate-bounce h-16" : isListening ? "animate-pulse h-12" : "opacity-40"}`} style={{ animationDelay: "0.2s" }} />
              <div className={`h-14 w-1 bg-violet-400 transition-all duration-300 ${isSpeaking ? "animate-bounce h-20" : isListening ? "animate-pulse h-14" : "opacity-40"}`} style={{ animationDelay: "0.3s" }} />
              <div className={`h-11 w-1 bg-indigo-500 transition-all duration-300 ${isSpeaking ? "animate-bounce h-16" : isListening ? "animate-pulse h-12" : "opacity-40"}`} style={{ animationDelay: "0.4s" }} />
              <div className={`h-8 w-1 rounded-full bg-cyan-500 transition-all duration-300 ${isSpeaking ? "animate-bounce h-12" : isListening ? "animate-pulse h-10" : "opacity-40"}`} style={{ animationDelay: "0.5s" }} />
            </div>

            <p className="text-[10px] text-gray-400 font-mono mt-3.5 text-center px-4 max-w-xs truncate">
              {isListening 
                ? "Listening... Speak now!" 
                : isSpeaking 
                ? "Voicing report findings aloud..." 
                : "Assistant is online. Click Mic or ask any Question."}
            </p>
          </div>

          {/* Message bubble thread box */}
          <div className="flex-1 p-4 overflow-y-auto space-y-3.5 bg-gray-950/20 scrollbar-thin scrollbar-thumb-gray-800">
            {messages.map((m, idx) => (
              <div key={idx} className={`flex ${m.sender === "user" ? "justify-end" : "justify-start"}`}>
                <div 
                  className={`max-w-[85%] rounded-2xl px-3.5 py-2.5 text-xs font-normal leading-relaxed ${
                    m.sender === "user"
                      ? "bg-gradient-to-tr from-cyan-600 to-indigo-600 text-white rounded-br-none border border-cyan-500/10"
                      : "bg-gray-900 border border-gray-850 text-gray-200 rounded-bl-none shadow-sm"
                  }`}
                >
                  {m.text}
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-gray-950/50 border border-gray-850/40 rounded-2xl p-3 flex items-center space-x-2">
                  <Loader2 className="h-3.5 w-3.5 animate-spin text-cyan-400" />
                  <span className="text-[10px] text-gray-400 font-mono tracking-wide">Linguistic synth in progress...</span>
                </div>
              </div>
            )}
            <div ref={chatEndRef} />
          </div>

          {/* Interactive action controls */}
          <div className="p-3 bg-gray-950 border-t border-gray-850">
            <form onSubmit={handleFormSubmit} className="flex gap-2 items-center">
              
              {/* Vocal Mic Speak button */}
              <button
                type="button"
                onClick={toggleListen}
                className={`h-9 w-9 rounded-xl flex items-center justify-center transition cursor-pointer ${
                  isListening 
                    ? "bg-red-500 text-white animate-pulse shadow-md shadow-red-500/20" 
                    : "bg-gray-900 text-cyan-400 hover:bg-gray-850 border border-gray-850 hover:text-white"
                }`}
                title="Speak to Assistant"
              >
                {isListening ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4 animate-pulse" />}
              </button>

              <input
                type="text"
                value={inputText}
                onChange={e => setInputText(e.target.value)}
                placeholder="Ask: 'How do I detect AI audio?'"
                className="flex-1 bg-gray-900 border border-gray-850 rounded-xl px-3 py-1.5 text-xs text-white placeholder-gray-550 focus:outline-none focus:border-cyan-500/40 focus:ring-1 focus:ring-cyan-500/20"
              />

              <button
                type="submit"
                disabled={!inputText.trim()}
                className="h-9 w-9 bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-white rounded-xl flex items-center justify-center transition cursor-pointer"
              >
                <Send className="h-4 w-4" />
              </button>
            </form>
          </div>
          
        </div>
      )}
    </>
  );
}
