import { User } from "../types";
import { ShieldCheck, LogOut, Sparkles, LayoutDashboard, Database, RefreshCw } from "lucide-react";

interface NavbarProps {
  user: User | null;
  onLogout: () => void;
  onNavigate: (view: 'main' | 'dashboard' | 'admin') => void;
  activeView: 'main' | 'dashboard' | 'admin';
  onTogglePlan: () => void;
}

export default function Navbar({ user, onLogout, onNavigate, activeView, onTogglePlan }: NavbarProps) {
  const isAdmin = user?.email === "liketobeadeveloper@gmail.com";

  return (
    <header className="sticky top-0 z-40 w-full border-b border-gray-800 bg-gray-950/80 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        {/* Logo */}
        <div className="flex items-center space-x-3 cursor-pointer" onClick={() => onNavigate('main')}>
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-tr from-cyan-500 via-blue-600 to-indigo-600 shadow-lg shadow-blue-500/20">
            <ShieldCheck className="h-6 w-6 text-white" />
          </div>
          <div>
            <span className="text-lg font-bold tracking-tight text-white">Authenti<span className="text-cyan-400 font-extrabold">AI</span></span>
            <div className="text-[10px] font-mono tracking-widest text-cyan-400 font-medium uppercase leading-3">Linguistic Audit</div>
          </div>
        </div>

        {/* Navigation and Actions */}
        {user ? (
          <div className="flex items-center space-x-4">
            <nav className="hidden md:flex items-center space-x-1 font-sans text-sm font-medium">
              <button
                onClick={() => onNavigate('main')}
                className={`flex items-center space-x-2 px-3 py-2 rounded-lg transition-colors ${
                  activeView === 'main' 
                    ? 'text-cyan-400 bg-gray-900/60' 
                    : 'text-gray-400 hover:text-white hover:bg-gray-900/30'
                }`}
              >
                <span>Analyzer Engine</span>
              </button>
              
              <button
                onClick={() => onNavigate('dashboard')}
                className={`flex items-center space-x-2 px-3 py-2 rounded-lg transition-colors ${
                  activeView === 'dashboard'
                    ? 'text-cyan-400 bg-gray-900/60'
                    : 'text-gray-400 hover:text-white hover:bg-gray-900/30'
                }`}
              >
                <LayoutDashboard className="h-4 w-4" />
                <span>My Dashboard</span>
              </button>

              {isAdmin && (
                <button
                  onClick={() => onNavigate('admin')}
                  className={`flex items-center space-x-2 px-3 py-2 rounded-lg transition-colors ${
                    activeView === 'admin'
                      ? 'text-indigo-400 bg-gray-900/60 border border-indigo-500/20'
                      : 'text-gray-400 hover:text-white hover:bg-gray-900/30'
                  }`}
                >
                  <Database className="h-4 w-4" />
                  <span>Admin Panel</span>
                </button>
              )}
            </nav>

            {/* Premium Pill toggle */}
            <button
              onClick={onTogglePlan}
              className={`flex items-center space-x-1.5 rounded-full px-3.5 py-1.5 text-xs font-semibold tracking-wide transition-all duration-300 ${
                user.subscriptionPlan === 'premium'
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-md shadow-blue-500/20 hover:opacity-90'
                  : 'bg-gray-900 text-gray-300 border border-gray-700 hover:bg-gray-800'
              }`}
            >
              <Sparkles className={`h-3.5 w-3.5 ${user.subscriptionPlan === 'premium' ? 'text-yellow-300 animate-spin-slow' : 'text-gray-400'}`} />
              <span>{user.subscriptionPlan === 'premium' ? 'Premium Unlimited' : 'Go Premium'}</span>
            </button>

            {/* Profile Menu */}
            <div className="flex items-center space-x-3 pl-2 border-l border-gray-800">
              <div className="flex flex-col text-right">
                <span className="text-xs font-semibold text-white max-w-[120px] truncate">{user.name}</span>
                <span className="text-[10px] text-gray-400 uppercase font-mono tracking-widest leading-3 mt-0.5">{user.subscriptionPlan} Tier</span>
              </div>
              <button
                onClick={onLogout}
                title="Log Out"
                className="flex h-9 w-9 items-center justify-center rounded-lg border border-gray-800 bg-gray-900/50 text-gray-400 hover:text-red-400 hover:border-red-950/50 hover:bg-red-950/10 transition-colors"
              >
                <LogOut className="h-4 w-4" />
              </button>
            </div>
          </div>
        ) : (
          <div className="hidden md:flex items-center space-x-2 text-sm font-medium">
            <span className="text-gray-400 text-xs py-2 px-3">Secure Enterprise Guard</span>
          </div>
        )}
      </div>
    </header>
  );
}
