import React, { useState, useEffect } from "react";
import { 
  Database, Users, FileText, AlertTriangle, ShieldAlert,
  Settings, RefreshCw, BarChart, Trash2, ArrowRightLeft, ShieldCheck 
} from "lucide-react";

interface AdminPanelProps {
  onSelectReport: (report: any) => void;
}

export default function AdminPanel({ onSelectReport }: AdminPanelProps) {
  const [metrics, setMetrics] = useState<any>(null);
  const [users, setUsers] = useState<any[]>([]);
  const [reports, setReports] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const fetchAdminData = async () => {
    setIsLoading(true);
    try {
      const [metricsRes, usersRes, reportsRes] = await Promise.all([
        fetch("/api/admin/metrics"),
        fetch("/api/admin/users"),
        fetch("/api/admin/reports")
      ]);

      const [metricsData, usersData, reportsData] = await Promise.all([
        metricsRes.json(),
        usersRes.json(),
        reportsRes.json()
      ]);

      setMetrics(metricsData);
      setUsers(usersData);
      setReports(reportsData);
    } catch (error) {
      console.error("Failed to load admin systems:", error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchAdminData();
  }, []);

  const handleToggleUserPlan = async (userId: string) => {
    try {
      const res = await fetch("/api/user/toggle-plan", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId })
      });
      if (res.ok) {
        setSuccessMsg("User plan toggled successfully.");
        fetchAdminData();
        setTimeout(() => setSuccessMsg(null), 3000);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleDeleteReport = async (reportId: string, userId: string) => {
    if (!confirm("Are you sure you want to delete this historical report permanently?")) return;
    try {
      const res = await fetch(`/api/reports/${reportId}/delete`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId })
      });
      if (res.ok) {
        setSuccessMsg("Linguistic report erased safely.");
        fetchAdminData();
        setTimeout(() => setSuccessMsg(null), 3000);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleResetSystemDB = async () => {
    if (!confirm("WARNING: Are you sure you want to wipe all scanned report logs from the database? This is irreversible.")) return;
    try {
      const res = await fetch("/api/admin/reset", { method: "POST" });
      if (res.ok) {
        setSuccessMsg("Systems database purge completed.");
        fetchAdminData();
        setTimeout(() => setSuccessMsg(null), 3000);
      }
    } catch (err) {
      console.error(err);
    }
  };

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center p-24 space-y-3">
        <RefreshCw className="h-8 w-8 text-cyan-400 animate-spin" />
        <span className="text-xs text-gray-400">Loading Secure Admin Modules...</span>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-12 space-y-8">
      
      {/* Admin Title bar */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-gray-900 pb-5">
        <div className="space-y-1">
          <div className="inline-flex items-center space-x-1 text-xs font-mono font-bold text-indigo-400 uppercase">
            System Console
          </div>
          <h1 className="text-2xl font-black text-white tracking-tight flex items-center space-x-2">
            <Database className="h-6 w-6 text-indigo-400 animate-pulse" />
            <span>Forensic Systems Controller</span>
          </h1>
        </div>

        <div className="flex items-center gap-2">
          {/* Refresh button */}
          <button
            onClick={fetchAdminData}
            title="Refresh logs"
            className="flex h-9 w-9 items-center justify-center rounded-lg border border-gray-850 bg-gray-900 text-gray-400 hover:text-white transition-colors cursor-pointer"
          >
            <RefreshCw className="h-4 w-4" />
          </button>

          <button
            onClick={handleResetSystemDB}
            className="rounded-lg bg-red-950/20 border border-red-900/30 hover:border-red-800 hover:bg-red-950/30 text-red-400 font-bold px-4 py-2 text-xs flex items-center space-x-1.5 transition-colors"
          >
            <Trash2 className="h-4 w-4" />
            <span>Purge Scans DB</span>
          </button>
        </div>
      </div>

      {successMsg && (
        <div className="rounded-xl border border-green-900 bg-green-950/20 p-4 text-xs font-semibold text-green-400">
          {successMsg}
        </div>
      )}

      {/* Aggregate Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-6">
        <div className="rounded-xl border border-gray-900 bg-gray-950/40 p-5 space-y-2">
          <div className="text-[10px] font-mono text-gray-500 uppercase">Total User Accounts</div>
          <div className="text-3xl font-black font-mono text-white">{metrics?.totalUsers}</div>
        </div>

        <div className="rounded-xl border border-gray-900 bg-gray-950/40 p-5 space-y-2">
          <div className="text-[10px] font-mono text-gray-500 uppercase">Total Verifications Processed</div>
          <div className="text-3xl font-black font-mono text-indigo-400">{metrics?.totalScans}</div>
        </div>

        <div className="rounded-xl border border-gray-900 bg-gray-950/40 p-5 space-y-2">
          <div className="text-[10px] font-mono text-gray-500 uppercase">Device Classifier Risk Verdicts</div>
          <div className="text-xs font-mono text-gray-400 flex flex-col space-y-1 mt-1 font-semibold">
            <span className="text-red-400">● AI Dominated: {metrics?.aiDetectedScans || 0}</span>
            <span className="text-green-400">● Human Autograph: {metrics?.humanDetectedScans || 0}</span>
          </div>
        </div>

        <div className="rounded-xl border border-gray-900 bg-gray-950/40 p-5 space-y-2">
          <div className="text-[10px] font-mono text-gray-500 uppercase">Average Machine Certitude</div>
          <div className="text-3xl font-black font-mono text-cyan-400">{metrics?.averageAIProbability || 0}%</div>
        </div>
      </div>

      {/* Systems catalog panels rows */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Users Catalog Table: Left 5-Cols */}
        <div className="lg:col-span-4 rounded-xl border border-gray-900 bg-gray-950/40 p-5 space-y-4">
          <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center space-x-2 border-b border-gray-900 pb-3">
            <Users className="h-4.5 w-4.5 text-indigo-400" />
            <span>Registered Accounts List</span>
          </h3>

          <div className="space-y-3.5 max-h-[350px] overflow-y-auto pr-1">
            {users.map((u) => (
              <div
                key={u.id}
                className="rounded-lg border border-gray-900 bg-gray-900/15 p-3 flex items-center justify-between text-xs"
              >
                <div className="min-w-0 pr-3">
                  <span className="font-bold text-white block truncate">{u.name || "None"}</span>
                  <span className="text-[10px] text-gray-500 font-mono block truncate">{u.email}</span>
                </div>

                <button
                  onClick={() => handleToggleUserPlan(u.id)}
                  className={`px-2.5 py-1 rounded text-[10px] shrink-0 font-bold border uppercase tracking-wider font-mono transition-colors cursor-pointer ${
                    u.subscriptionPlan === "premium"
                      ? "bg-cyan-950/20 text-cyan-400 border-cyan-800/40 hover:bg-cyan-950/40"
                      : "bg-gray-950/50 text-gray-400 border-gray-800 hover:text-white"
                  }`}
                >
                  {u.subscriptionPlan} plan
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Generated Reports logs Table: Right 8-Cols */}
        <div className="lg:col-span-8 rounded-xl border border-gray-900 bg-gray-950/40 p-5 space-y-4">
          <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center space-x-2 border-b border-gray-900 pb-3">
            <FileText className="h-4.5 w-4.5 text-indigo-400" />
            <span>Verification Scan audit log</span>
          </h3>

          <div className="space-y-3.5 max-h-[350px] overflow-y-auto pr-1">
            {reports.length === 0 ? (
              <div className="text-center py-12 text-xs text-gray-500 leading-normal">
                No scans have been executed through the platform database yet.
              </div>
            ) : (
              reports.map((r) => {
                const authorUser = users.find(u => u.id === r.userId);
                return (
                  <div
                    key={r.id}
                    className="rounded-lg border border-gray-900 bg-gray-900/15 p-3.5 flex items-center justify-between gap-4 text-xs"
                  >
                    <div className="min-w-0">
                      <span 
                        onClick={() => onSelectReport(r)}
                        className="font-bold text-white hover:text-cyan-400 hover:underline cursor-pointer block truncate"
                      >
                        {r.fileName}
                      </span>
                      <span className="text-[10px] text-gray-500 font-mono block mt-0.5 truncate uppercase">
                        By User: {authorUser?.name || "System Master"} &bull; {r.wordCount} words
                      </span>
                    </div>

                    <div className="flex items-center space-x-3 text-right shrink-0">
                      <div className="font-mono">
                        <span className={`font-bold block ${r.aiProbability >= 50 ? "text-red-400" : "text-green-400"}`}>
                          {r.aiProbability}% AI
                        </span>
                        <span className="text-[9px] text-gray-500 block uppercase font-mono">{r.riskLevel} Risk</span>
                      </div>

                      <button
                        onClick={() => handleDeleteReport(r.id, r.userId)}
                        title="Eraser scan log"
                        className="h-8 w-8 flex items-center justify-center rounded-lg hover:bg-red-950/20 text-gray-500 hover:text-red-400 transition-colors cursor-pointer border border-transparent hover:border-red-950/20"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

      </div>

    </div>
  );
}
