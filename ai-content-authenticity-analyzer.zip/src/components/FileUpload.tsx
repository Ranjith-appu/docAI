import React, { useState, useRef } from "react";
import { UploadCloud, FileText, AlertCircle, Sparkles, HelpCircle, Loader2 } from "lucide-react";
import { User } from "../types";

interface FileUploadProps {
  user: User;
  onAnalyze: (file: File) => void;
  isAnalyzing: boolean;
  errorMsg: string | null;
}

export default function FileUpload({ user, onAnalyze, isAnalyzing, errorMsg }: FileUploadProps) {
  const [dragActive, setDragActive] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [localError, setLocalError] = useState<string | null>(null);
  const [progress, setProgress] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const validateAndSetFile = (file: File | null) => {
    if (!file) return;

    // Maximum file sizes: Free plan: 2MB; Premium plan: 40MB
    const sizeLimit = user.subscriptionPlan === "premium" ? 40 * 1024 * 1024 : 2 * 1024 * 1024;
    const sizeLimitText = user.subscriptionPlan === "premium" ? "40MB" : "2MB";

    if (file.size > sizeLimit) {
      setLocalError(`File size exceeds your plan limit (${sizeLimitText}). Premium allows documents and media objects up to 40MB.`);
      return;
    }

    setLocalError(null);
    setSelectedFile(file);
    setProgress(0);

    if (file.type.toLowerCase().startsWith("image/")) {
      const url = URL.createObjectURL(file);
      setImagePreview(url);
    } else {
      setImagePreview(null);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      validateAndSetFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      validateAndSetFile(e.target.files[0]);
    }
  };

  const onButtonClick = () => {
    fileInputRef.current?.click();
  };

  const handleStartAnalysis = () => {
    if (!selectedFile) return;

    // Simulate upload progress
    let currentProgress = 0;
    const interval = setInterval(() => {
      currentProgress += 10;
      if (currentProgress < 100) {
        setProgress(currentProgress);
      } else {
        clearInterval(interval);
        setProgress(100);
        onAnalyze(selectedFile);
      }
    }, 80);
  };

  const clearSelection = () => {
    if (imagePreview) {
      URL.revokeObjectURL(imagePreview);
    }
    setSelectedFile(null);
    setImagePreview(null);
    setProgress(0);
  };

  const isImageFile = selectedFile && (selectedFile.type.toLowerCase().startsWith("image/") || ["png", "jpg", "jpeg", "webp", "gif"].some(ext => selectedFile.name.toLowerCase().endsWith("." + ext)));
  const isAudioFile = selectedFile && (selectedFile.type.toLowerCase().startsWith("audio/") || ["mp3", "wav", "ogg", "mpeg", "m4a"].some(ext => selectedFile.name.toLowerCase().endsWith("." + ext)));

  return (
    <div className="mx-auto max-w-3xl px-4 py-12">
      {/* Dynamic warning if free and daily scans reached */}
      <div className="bg-gray-900 border border-gray-800 rounded-2xl p-6 mb-8 flex items-center justify-between">
        <div className="space-y-1">
          <div className="text-sm font-semibold text-white">Daily Limit Dashboard</div>
          <p className="text-xs text-gray-400">
            You are on the <span className="text-cyan-400 font-semibold">{user.subscriptionPlan.toUpperCase()} plan</span>. 
            Used: <span className="text-white font-bold">{user.analysesToday}/5</span> scans today.
          </p>
        </div>
        <div className="h-2 w-32 bg-gray-950 rounded-full overflow-hidden border border-gray-800">
          <div 
            className="h-full bg-gradient-to-r from-cyan-500 to-blue-600 transition-all duration-300"
            style={{ width: `${Math.min(100, (user.analysesToday / 5) * 100)}%` }}
          />
        </div>
      </div>

      {/* Main Drag Box */}
      <h2 className="text-2xl font-bold tracking-tight text-white mb-2 text-center">Analyze Document & Media Authenticity</h2>
      <p className="text-gray-400 text-xs text-center mb-8 max-w-md mx-auto">
        Verify research papers, program scripts, image artifacts (PNG, JPG) or synthetic voice audio clips (MP3, WAV).
      </p>

      {(errorMsg || localError) && (
        <div className="mb-6 rounded-xl border border-red-900 bg-red-950/20 p-4 text-xs text-red-400 flex items-center space-x-2">
          <AlertCircle className="h-5 w-5 text-red-500 flex-shrink-0" />
          <span>{errorMsg || localError}</span>
        </div>
      )}

      {!selectedFile ? (
        <div
          onDragEnter={handleDrag}
          onDragOver={handleDrag}
          onDragLeave={handleDrag}
          onDrop={handleDrop}
          onClick={onButtonClick}
          className={`flex flex-col items-center justify-center border-2 border-dashed rounded-2xl p-12 text-center cursor-pointer transition-all ${
            dragActive 
              ? "border-cyan-400 bg-cyan-950/20 shadow-inner" 
              : "border-gray-800 bg-gray-900/10 hover:border-gray-700 hover:bg-gray-900/20"
          }`}
        >
          <input
            ref={fileInputRef}
            type="file"
            className="hidden"
            accept=".pdf,.docx,.txt,.js,.py,.java,.cpp,.html,.css,image/*,audio/*"
            onChange={handleFileChange}
          />

          <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-gray-900 border border-gray-850 text-gray-400 mb-6 shadow-sm">
            <UploadCloud className="h-7 w-7 text-cyan-400" />
          </div>

          <h3 className="text-md font-bold text-white mb-2">Drag & Drop Your File Here</h3>
          <p className="text-xs text-gray-500 max-w-xs mx-auto leading-relaxed">
            or <span className="text-cyan-400 font-semibold hover:underline">browse files</span>. Max size: {user.subscriptionPlan === "premium" ? "40MB" : "2MB"}.
          </p>

          <div className="mt-8 flex flex-wrap gap-2 justify-center">
            <span className="rounded-md border border-gray-850 px-2.5 py-1 text-[10px] font-mono text-gray-400 uppercase">Documents</span>
            <span className="rounded-md border border-gray-850 px-2.5 py-1 text-[10px] font-mono text-gray-400 uppercase">PNG / JPG</span>
            <span className="rounded-md border border-gray-850 px-2.5 py-1 text-[10px] font-mono text-gray-400 uppercase">MP3 / WAV</span>
            <span className="rounded-md border border-gray-850 px-2.5 py-1 text-[10px] font-mono text-gray-400 uppercase">Source Code</span>
          </div>
        </div>
      ) : (
        /* File selection details and analysis trigger */
        <div className="rounded-2xl border border-gray-800 bg-gray-900/30 p-8 space-y-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              {imagePreview ? (
                <div className="h-11 w-11 rounded-xl overflow-hidden border border-gray-800 flex-shrink-0 bg-neutral-950 flex items-center justify-center">
                  <img src={imagePreview} className="h-full w-full object-cover" alt="Image scanner thumbnail" referrerPolicy="no-referrer" />
                </div>
              ) : isAudioFile ? (
                <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-indigo-950/50 border border-indigo-500/20 text-indigo-400 flex-shrink-0">
                  <span className="text-lg">🎙️</span>
                </div>
              ) : (
                <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-cyan-950/50 border border-cyan-500/20 text-cyan-400 flex-shrink-0">
                  <FileText className="h-6 w-6" />
                </div>
              )}
              <div className="min-w-0 flex-1">
                <span className="text-sm font-bold text-white block truncate max-w-xs">{selectedFile.name}</span>
                <span className="text-[10px] text-gray-500 font-mono tracking-wider mt-0.5 block">
                  {(selectedFile.size / 1024).toFixed(1)} KB &bull; {selectedFile.type || "Forensic stream asset"}
                </span>
              </div>
            </div>
            {!isAnalyzing && (
              <button 
                onClick={clearSelection}
                className="text-xs font-semibold text-gray-450 hover:text-red-400 cursor-pointer flex-shrink-0 ml-3"
              >
                Remove
              </button>
            )}
          </div>

          {/* Trigger button & upload simulated speed */}
          {progress > 0 && (
            <div className="space-y-2">
              <div className="flex justify-between text-xs">
                <span className="text-gray-400">Preparing forensic scan buffers...</span>
                <span className="text-cyan-400 font-bold font-mono">{progress}%</span>
              </div>
              <div className="h-1.5 w-full bg-gray-950 rounded-full overflow-hidden border border-gray-850">
                <div 
                  className="h-full bg-gradient-to-r from-cyan-400 to-indigo-600 transition-all duration-100"
                  style={{ width: `${progress}%` }}
                />
              </div>
            </div>
          )}

          {isAnalyzing ? (
            <div className="rounded-xl border border-cyan-950 bg-cyan-950/10 p-5 space-y-3 flex flex-col items-center justify-center text-center">
              <Loader2 className="h-8 w-8 text-cyan-400 animate-spin" />
              <div className="text-xs font-bold text-white mt-2">Computing Forensic Classification</div>
              <p className="text-[10px] text-cyan-400 font-mono tracking-wide max-w-xs leading-normal">
                {isImageFile 
                  ? "Evaluating anatomical symmetries, inspecting shadow projection vectors, and identifying texture map smoothness..."
                  : isAudioFile
                  ? "Scanning pitch uniformity intonation, assessing respiration intervals, and checking spectral flat lines..."
                  : "Dissecting perplexity curves, evaluating sentence burstiness variance, and highlighting syntax artifacts..."}
              </p>
            </div>
          ) : (
            <button
              onClick={handleStartAnalysis}
              className="w-full flex items-center justify-center space-x-2 rounded-xl bg-gradient-to-r from-cyan-500 to-indigo-600 hover:opacity-95 text-white py-3.5 px-4 font-bold shadow-lg shadow-blue-500/20 cursor-pointer"
            >
              <Sparkles className="h-4.5 w-4.5 text-yellow-300 animate-pulse" />
              <span>Verify Media Authenticity</span>
            </button>
          )}
        </div>
      )}

      {/* Helpful Hint */}
      <div className="mt-8 rounded-xl border border-gray-850/60 bg-gray-900/10 p-5 flex space-x-3.5 items-start">
        <HelpCircle className="h-5 w-5 text-gray-400 flex-shrink-0 mt-0.5" />
        <div className="space-y-1">
          <div className="text-xs font-bold text-gray-300">How to inspect Media & Audio clips?</div>
          <p className="text-[11px] text-gray-500 leading-relaxed font-normal">
            Drag any image or vocal clip onto our analyzer. Our upgraded multimodal engine can hear phonetic flatlines in suspicious speech recordings and spot waxy edge anomalies in synthesized image graphics instantly!
          </p>
        </div>
      </div>
    </div>
  );
}
