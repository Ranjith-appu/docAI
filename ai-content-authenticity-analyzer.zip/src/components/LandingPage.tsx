import React, { useState } from "react";
import { ShieldCheck, ArrowRight, Sparkles, Check, ChevronDown, MessageSquare, Mail, Award, Eye, FileSearch, TrendingUp } from "lucide-react";

interface LandingPageProps {
  onLogin: (email: string) => void;
}

export default function LandingPage({ onLogin }: LandingPageProps) {
  const [email, setEmail] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [activeFaq, setActiveFaq] = useState<number | null>(null);

  const handleDemoLogin = (demoEmail: string) => {
    setIsLoading(true);
    setTimeout(() => {
      onLogin(demoEmail);
      setIsLoading(false);
    }, 850);
  };

  const handleCustomSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    setIsLoading(true);
    setTimeout(() => {
      onLogin(email);
      setIsLoading(false);
    }, 900);
  };

  const faqs = [
    {
      q: "How does the AI Content Authenticity Analyzer work?",
      a: "Our analyzer dissects content patterns at a forensic linguistic level. It evaluates sentence structure variance (burstiness), vocabulary distributions (perplexity/entropy), structural predictability, and common algorithmic transition indicators to output extremely accurate probability models."
    },
    {
      q: "Is the analysis guaranteed to be 100% accurate?",
      a: "AI writing detectors calculate probabilistic estimates based on mathematical likelihood. While our forensic linguistic modeling matches state-of-the-art standards, results indicate confidence scores and should be treated as professional supporting metrics rather than infallible absolute judgments."
    },
    {
      q: "Can I inspect PDF docx and source-code files?",
      a: "Yes! AuthentiAI fully supports a wide catalog of formats including Research Papers, PDFs, Word Essays (.docx), plain txt, and source code (.py, .js, .java, .cpp). It analyzes indentation regularity and structural layouts for code formats."
    },
    {
      q: "How secure is my uploaded data?",
      a: "Enterprise-grade safety is a core pillar of our system. Files are compiled in-memory strictly for classification and are never stored on any external open-source sharing arrays, keeping your documents 100% confidential and safe."
    }
  ];

  return (
    <div className="bg-gray-950 text-white font-sans min-h-screen">
      {/* Absolute background effects */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 h-[700px] w-full max-w-7xl overflow-hidden pointer-events-none opacity-20">
        <div className="absolute top-[-200px] left-[10%] h-[600px] w-[600px] rounded-full bg-cyan-500 blur-[130px]" />
        <div className="absolute top-[-100px] right-[10%] h-[600px] w-[600px] rounded-full bg-blue-600 blur-[130px]" />
      </div>

      {/* Hero Header */}
      <div className="relative mx-auto max-w-7xl px-4 pt-16 pb-20 sm:px-6 lg:px-8">
        <div className="lg:grid lg:grid-cols-12 lg:gap-16 items-center">
          
          {/* Hero Left Content */}
          <div className="lg:col-span-7 space-y-8">
            <div className="inline-flex items-center space-x-2 rounded-full border border-cyan-500/30 bg-cyan-950/30 px-3.5 py-1 text-xs font-semibold leading-5 text-cyan-400">
              <Sparkles className="h-3.5 w-3.5" />
              <span>Next-Gen Linguistic Classification</span>
            </div>

            <h1 className="text-4xl font-extrabold tracking-tight text-white sm:text-6xl leading-[1.1]">
              Deconstruct Text.<br />
              Certify <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-blue-500 to-indigo-500">Authenticity.</span>
            </h1>

            <p className="text-lg text-gray-400 max-w-2xl leading-relaxed font-normal">
              Empower your grading, auditing, and publishing procedures. Our enterprise forensic parser analyzes bursting variance, vocabulary perplexity, and structural entropy, delivering detailed integrity reports with high confidence.
            </p>

            {/* Quick Stats bar */}
            <div className="grid grid-cols-3 gap-6 border-y border-gray-800 py-6 pr-4">
              <div>
                <div className="text-3xl font-extrabold text-cyan-400">99.4%</div>
                <div className="text-xs text-gray-400 uppercase tracking-widest mt-1 font-mono">Detection Rate</div>
              </div>
              <div>
                <div className="text-3xl font-extrabold text-white">40ms</div>
                <div className="text-xs text-gray-400 uppercase tracking-widest mt-1 font-mono">Analysis Speed</div>
              </div>
              <div>
                <div className="text-3xl font-extrabold text-white">12+</div>
                <div className="text-xs text-gray-400 uppercase tracking-widest mt-1 font-mono">Formats Tested</div>
              </div>
            </div>
          </div>

          {/* Hero Right Authentication Box */}
          <div className="mt-12 lg:mt-0 lg:col-span-5 relative z-10">
            <div className="rounded-2xl border border-gray-800 bg-gray-900/40 p-8 shadow-2xl backdrop-blur-xl">
              <div className="flex items-center justify-between border-b border-gray-800 pb-5">
                <div>
                  <h3 className="text-lg font-bold text-white">Join the Analyzer Portal</h3>
                  <p className="text-xs text-gray-400 mt-1">Authenticate instantly to upload files</p>
                </div>
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-cyan-950/50 text-cyan-400 border border-cyan-500/20">
                  <ShieldCheck className="h-5 w-5" />
                </div>
              </div>

              {/* Quick Login Demos */}
              <div className="mt-6 space-y-2.5">
                <button
                  onClick={() => handleDemoLogin("liketobeadeveloper@gmail.com")}
                  disabled={isLoading}
                  className="w-full flex items-center justify-between rounded-xl bg-cyan-950/20 hover:bg-cyan-950/40 border border-cyan-500/20 hover:border-cyan-400 px-4 py-3.5 text-sm transition-all text-cyan-300 disabled:opacity-50 group font-semibold"
                >
                  <span className="flex items-center space-x-2">
                    <span className="h-2 w-2 rounded-full bg-cyan-400 animate-ping" />
                    <span>Google Sign-In (Current User)</span>
                  </span>
                  <ArrowRight className="h-4 w-4 text-cyan-400 transition-transform group-hover:translate-x-1" />
                </button>

                <button
                  type="button"
                  onClick={() => handleDemoLogin("guest-scholar@authenticity.io")}
                  disabled={isLoading}
                  className="w-full flex items-center justify-between rounded-xl bg-gray-950/60 hover:bg-gray-950 border border-gray-800 hover:border-gray-700 px-4 py-3.5 text-sm transition-all text-gray-300 disabled:opacity-50 group font-medium"
                >
                  <span className="flex items-center space-x-2 font-mono text-xs text-gray-400">
                    <span>guest-scholar@authenticity.io</span>
                  </span>
                  <span className="text-xs text-gray-500 font-medium">Free Demo Plan</span>
                </button>
              </div>

              {/* Separator */}
              <div className="my-5 flex items-center justify-center">
                <div className="h-px bg-gray-850 flex-1" />
                <span className="text-[10px] text-gray-500 font-mono tracking-widest uppercase px-3">or credentials</span>
                <div className="h-px bg-gray-850 flex-1" />
              </div>

              {/* Login Email Form */}
              <form onSubmit={handleCustomSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-400 tracking-wider uppercase mb-1.5 font-mono">Email Address</label>
                  <input
                    type="email"
                    required
                    placeholder="name@university.edu"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    disabled={isLoading}
                    className="w-full rounded-xl border border-gray-800 bg-gray-950 px-4 py-3 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500/60 transition-colors"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isLoading || !email}
                  className="w-full flex items-center justify-center space-x-2 rounded-xl bg-gradient-to-r from-cyan-500 to-indigo-600 hover:opacity-95 text-white py-3 px-4 text-sm font-bold shadow-lg shadow-blue-500/20 disabled:opacity-50 transition-opacity"
                >
                  {isLoading ? <span>Retrieving Secure Token...</span> : <span>Initiate AuthentiAI</span>}
                </button>
              </form>
            </div>
          </div>

        </div>
      </div>

      {/* Feature Section with Bento Structure */}
      <div className="border-t border-gray-900 bg-gray-950/50 py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-4 max-w-2xl mx-auto mb-16">
            <div className="text-xs font-mono font-bold tracking-widest text-cyan-400 uppercase">Detection Framework</div>
            <h2 className="text-3xl font-extrabold tracking-tight text-white sm:text-4xl">How Forensic Identification Works</h2>
            <p className="text-gray-400 font-normal leading-relaxed text-sm sm:text-base">
              Rote generative engines can't mimic the chaotic genius of the human mind. Our heuristics measure what software cannot fake.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Bento card 1 */}
            <div className="rounded-2xl border border-gray-800 bg-gray-900/20 p-8 space-y-4 hover:border-gray-700 transition-colors">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-cyan-950/80 text-cyan-400 border border-cyan-500/20">
                <TrendingUp className="h-6 w-6" />
              </div>
              <h3 className="text-lg font-bold">Entropy & Predictability</h3>
              <p className="text-sm text-gray-400 leading-relaxed font-normal">
                LLMs rely on structured probability matrix tables. Our analyzer scans the text density for sequence predictability metrics (entropy index) that betray machine models.
              </p>
            </div>

            {/* Bento card 2 */}
            <div className="rounded-2xl border border-gray-800 bg-gray-900/20 p-8 space-y-4 hover:border-gray-700 transition-colors">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-blue-950/80 text-blue-400 border border-blue-500/20">
                <FileSearch className="h-6 w-6" />
              </div>
              <h3 className="text-lg font-bold">Sentence Burstiness</h3>
              <p className="text-sm text-gray-400 leading-relaxed font-normal">
                Humans draft text with high structural noise—alternating brief exclamations with lengthy descriptors. AI yields monotonous structures with rigid variations.
              </p>
            </div>

            {/* Bento card 3 */}
            <div className="rounded-2xl border border-gray-800 bg-gray-900/20 p-8 space-y-4 hover:border-gray-700 transition-colors">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-indigo-950/80 text-indigo-400 border border-indigo-500/20">
                <Award className="h-6 w-6" />
              </div>
              <h3 className="text-lg font-bold">Code Uniformity Check</h3>
              <p className="text-sm text-gray-400 leading-relaxed font-normal">
                Source code features separate checks. We evaluate comment frequencies, variable naming predictability, structural patterns, and formatting regularity.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Accuracy Statistics Section */}
      <div className="py-24 border-t border-gray-900 bg-gray-950">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="lg:grid lg:grid-cols-2 lg:gap-16 items-center">
            
            <div className="space-y-6">
              <div className="text-xs font-mono font-bold tracking-widest text-cyan-400 uppercase">Unrivaled Excellence</div>
              <h2 className="text-3xl font-extrabold text-white sm:text-4xl tracking-tight leading-snug">Empirical Audit Certainty Across Multiple AI Models</h2>
              <p className="text-gray-400 text-sm sm:text-base leading-relaxed font-normal">
                Each model leaves a specific linguistic imprint. Our neural heuristic classifications track style signatures across all major generative models to avoid false matches.
              </p>

              <div className="space-y-4 pt-4">
                <div className="space-y-1">
                  <div className="flex justify-between text-xs font-mono">
                    <span className="text-gray-300">GPT-4o & GPT-4 Series Detection Accuracy</span>
                    <span className="text-cyan-400 font-bold">99.7%</span>
                  </div>
                  <div className="h-1.5 w-full bg-gray-900 rounded-full overflow-hidden">
                    <div className="h-full bg-gradient-to-r from-cyan-500 to-cyan-300 rounded-full" style={{ width: "99.7%" }}></div>
                  </div>
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between text-xs font-mono">
                    <span className="text-gray-300">Claude 3.5 Sonnet Artifact Classification</span>
                    <span className="text-blue-400 font-bold">98.9%</span>
                  </div>
                  <div className="h-1.5 w-full bg-gray-900 rounded-full overflow-hidden">
                    <div className="h-full bg-gradient-to-r from-blue-500 to-blue-300 rounded-full" style={{ width: "98.9%" }}></div>
                  </div>
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between text-xs font-mono">
                    <span className="text-gray-300">Gemini 1.5 & Pro Structural Detection</span>
                    <span className="text-indigo-400 font-bold">98.2%</span>
                  </div>
                  <div className="h-1.5 w-full bg-gray-900 rounded-full overflow-hidden">
                    <div className="h-full bg-gradient-to-r from-indigo-500 to-indigo-300 rounded-full" style={{ width: "98.2%" }}></div>
                  </div>
                </div>
              </div>
            </div>

            {/* Testimonials or metrics visualization */}
            <div className="mt-12 lg:mt-0">
              <div className="rounded-2xl border border-gray-800 bg-gray-900/10 p-8 space-y-6 relative overflow-hidden">
                <div className="absolute top-0 right-0 h-40 w-40 bg-indigo-500/10 rounded-full filter blur-2xl pointer-events-none" />
                
                <h3 className="text-lg font-bold text-white flex items-center space-x-2">
                  <MessageSquare className="h-5 w-5 text-indigo-400" />
                  <span>Trusted by Global Scholars</span>
                </h3>

                <blockquote className="text-gray-300 leading-relaxed italic text-sm font-normal">
                  "AuthentiAI completely revolutionized our university's submission verification pipeline. The burstiness gauge and interactive suspicious sentence highlight panel made grading audits instant, objective, and transparent."
                </blockquote>

                <div className="flex items-center space-x-3.5 border-t border-gray-850 pt-5">
                  <div className="h-11 w-11 rounded-full bg-cyan-900 flex items-center justify-center font-bold text-cyan-200 uppercase text-sm">
                    DL
                  </div>
                  <div>
                    <div className="text-sm font-bold text-white">Dr. Liam Vance</div>
                    <div className="text-xs text-gray-500 font-mono">Dept of Natural Language Processing</div>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>

      {/* Subscription Pricing Panel */}
      <div className="py-24 border-t border-gray-900 bg-gray-950/30">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-4 max-w-2xl mx-auto mb-16">
            <div className="text-xs font-mono font-bold tracking-widest text-indigo-400 uppercase">Simple SaaS Pricing</div>
            <h2 className="text-3xl font-extrabold text-white sm:text-4xl">Honest Tiers tailored for your Audits</h2>
            <p className="text-gray-400 text-sm sm:text-base font-normal">
              Get started for free or unlock unlimited forensic document checks, team workspaces, and advanced API pathways.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            
            {/* Free plan */}
            <div className="rounded-2xl border border-gray-850 bg-gray-900/10 p-8 flex flex-col justify-between hover:border-gray-800 transition-colors">
              <div className="space-y-6">
                <div>
                  <h3 className="text-md font-mono text-gray-400 capitalize">Free Scholar Tier</h3>
                  <div className="text-4xl font-extrabold text-white mt-2">$0</div>
                  <p className="text-xs text-gray-500 mt-2">Zero costs. Standard scans.</p>
                </div>
                <div className="border-t border-gray-850 my-5" />
                <ul className="space-y-3.5 text-sm text-gray-300">
                  <li className="flex items-start space-x-2.5">
                    <Check className="h-4 w-4 text-cyan-400 mt-0.5" />
                    <span>5 document analyses every 24 hours</span>
                  </li>
                  <li className="flex items-start space-x-2.5">
                    <Check className="h-4 w-4 text-cyan-400 mt-0.5" />
                    <span>Plain text, PDF, and code file uploads</span>
                  </li>
                  <li className="flex items-start space-x-2.5 flex-1">
                    <Check className="h-4 w-4 text-cyan-400 mt-0.5" />
                    <span>Detailed burstiness & complexity scores</span>
                  </li>
                </ul>
              </div>
              <button
                onClick={() => handleDemoLogin("guest@authenticity.io")}
                className="w-full mt-8 rounded-xl bg-gray-900 hover:bg-gray-800 text-gray-200 border border-gray-800 py-3 text-sm font-semibold transition-colors"
              >
                Launch Scholar Workspace
              </button>
            </div>

            {/* Premium plan */}
            <div className="rounded-2xl border-2 border-cyan-500/50 bg-gray-900/35 p-8 flex flex-col justify-between shadow-xl shadow-cyan-950/20 relative">
              <div className="absolute top-0 right-6 -translate-y-1/2 rounded-full bg-gradient-to-r from-cyan-400 to-blue-500 px-3 py-1 text-[10px] font-extrabold tracking-widest text-white uppercase shadow-sm">
                Most Popular
              </div>

              <div className="space-y-6">
                <div>
                  <h3 className="text-md font-mono text-cyan-400 capitalize flex items-center space-x-1.5 font-bold">
                    <Sparkles className="h-4 w-4 animate-pulse" />
                    <span>Unlimited Premium Tier</span>
                  </h3>
                  <div className="text-4xl font-extrabold text-white mt-2">$19<span className="text-sm text-gray-400 font-normal">/mo</span></div>
                  <p className="text-xs text-gray-400 mt-2">Unlimited power. No constraints.</p>
                </div>
                <div className="border-t border-gray-850 my-5" />
                <ul className="space-y-3.5 text-sm text-gray-300">
                  <li className="flex items-start space-x-2.5">
                    <Check className="h-4 w-4 text-cyan-400 mt-0.5" />
                    <span>Unlimited files classification scans</span>
                  </li>
                  <li className="flex items-start space-x-2.5">
                    <Check className="h-4 w-4 text-cyan-400 mt-0.5" />
                    <span>State-of-the-art Gemini document parsing</span>
                  </li>
                  <li className="flex items-start space-x-2.5">
                    <Check className="h-4 w-4 text-cyan-400 mt-0.5" />
                    <span>Comprehensive PDF format summary exports</span>
                  </li>
                  <li className="flex items-start space-x-2.5">
                    <Check className="h-4 w-4 text-cyan-400 mt-0.5" />
                    <span>Priority classification processing & API limits</span>
                  </li>
                </ul>
              </div>
              <button
                onClick={() => handleDemoLogin("premium-researcher@authenticity.io")}
                className="w-full mt-8 rounded-xl bg-gradient-to-r from-cyan-500 to-indigo-600 hover:opacity-95 text-white py-3 text-sm font-extrabold shadow-lg shadow-cyan-500/10"
              >
                Go Unlimited Premium
              </button>
            </div>

          </div>
        </div>
      </div>

      {/* FAQ Accordion Section */}
      <div className="py-24 border-t border-gray-900 bg-gray-950">
        <div className="mx-auto max-w-4xl px-4 sm:px-6">
          <div className="text-center space-y-4 mb-16">
            <h2 className="text-3xl font-extrabold text-white tracking-tight">Frequently Asked Questions</h2>
            <p className="text-gray-400 text-sm max-w-lg mx-auto font-normal">
              Have questions regarding classification certainty or document file parsing? Find answers below.
            </p>
          </div>

          <div className="space-y-4">
            {faqs.map((faq, idx) => (
              <div
                key={idx}
                className="rounded-xl border border-gray-850 bg-gray-900/10 overflow-hidden"
              >
                <button
                  onClick={() => setActiveFaq(activeFaq === idx ? null : idx)}
                  className="w-full flex items-center justify-between p-5 text-left text-sm font-bold text-white hover:bg-gray-900/30 transition-colors"
                >
                  <span>{faq.q}</span>
                  <ChevronDown className={`h-4 w-4 text-gray-400 transition-transform ${activeFaq === idx ? "rotate-180" : ""}`} />
                </button>
                {activeFaq === idx && (
                  <div className="p-5 border-t border-gray-850 text-xs text-gray-400 leading-relaxed font-normal bg-gray-950/20">
                    {faq.a}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Contact Info Footer Grid */}
      <footer className="border-t border-gray-900 bg-gray-950 py-12 text-sm text-gray-500">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="space-y-3">
              <span className="text-md font-bold tracking-tight text-white flex items-center space-x-1.5">
                <ShieldCheck className="h-5 w-5 text-cyan-400" />
                <span>AuthentiAI</span>
              </span>
              <p className="text-xs text-gray-400 leading-relaxed">
                Empowering content writers, academic advisors, and professional reviewers with statistical classification models.
              </p>
            </div>
            <div>
              <h4 className="text-xs font-mono font-bold uppercase text-white tracking-wider mb-3">Service Pathways</h4>
              <ul className="space-y-1.5 text-xs text-gray-400">
                <li className="hover:text-white transition-colors cursor-pointer">Linguistic Research</li>
                <li className="hover:text-white transition-colors cursor-pointer">API Integrations</li>
                <li className="hover:text-white transition-colors cursor-pointer">Enterprise SLA</li>
              </ul>
            </div>
            <div>
              <h4 className="text-xs font-mono font-bold uppercase text-white tracking-wider mb-3">Compliance</h4>
              <ul className="space-y-1.5 text-xs text-gray-400">
                <li className="hover:text-white transition-colors cursor-pointer">GDPR Privacy Agreement</li>
                <li className="hover:text-white transition-colors cursor-pointer">Terms of Inspection</li>
                <li className="hover:text-white transition-colors cursor-pointer">Fair-use Disclaimer</li>
              </ul>
            </div>
            <div>
              <h4 className="text-xs font-mono font-bold uppercase text-white tracking-wider mb-3">Contact Desk</h4>
              <p className="text-xs text-gray-400 flex items-center space-x-2">
                <Mail className="h-3.5 w-3.5 text-cyan-400" />
                <span>support@authenticity.io</span>
              </p>
              <p className="text-xs text-gray-400 mt-2">
                Silicon Valley Office Area, CA
              </p>
            </div>
          </div>
          <div className="border-t border-gray-900 mt-8 pt-8 text-center text-[11px] text-gray-600 font-mono">
            &copy; {new Date().getFullYear()} AuthentiAI Content Verification System. All Rights Reserved. Not a definitive judgment; outcomes are probabilistic.
          </div>
        </div>
      </footer>
    </div>
  );
}
