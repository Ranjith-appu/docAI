import React, { useState } from "react";
import { 
  ShieldCheck, AlertTriangle, CheckCircle, HelpCircle, 
  Printer, Share2, Download, RefreshCw, ChevronRight,
  TrendingUp, Compass, Award, FileSpreadsheet
} from "lucide-react";
import { AnalysisReport } from "../types";

interface ReportDashboardProps {
  report: AnalysisReport;
  onClose: () => void;
}

export default function ReportDashboard({ report, onClose }: ReportDashboardProps) {
  const [activeHighlight, setActiveHighlight] = useState<string | null>(
    report.highlights && report.highlights.length > 0 ? report.highlights[0].id : null
  );
  const [copied, setCopied] = useState(false);

  // Get color schemes based on Risk levels
  const getRiskDetails = (level: string) => {
    switch (level) {
      case "Critical":
        return { color: "text-red-500", bg: "bg-red-950/25", border: "border-red-900", badge: "bg-red-500/20 text-red-400" };
      case "High":
        return { color: "text-orange-500", bg: "bg-orange-950/25", border: "border-orange-900", badge: "bg-orange-500/20 text-orange-400" };
      case "Moderate":
        return { color: "text-yellow-500", bg: "bg-yellow-950/25", border: "border-yellow-900", badge: "bg-yellow-500/10 text-yellow-400" };
      default:
        return { color: "text-green-500", bg: "bg-green-950/25", border: "border-green-900", badge: "bg-green-500/20 text-green-400" };
    }
  };

  const risk = getRiskDetails(report.riskLevel);

  const isImage = report.fileType.toLowerCase().startsWith("image/") || ["png", "jpg", "jpeg", "webp", "gif"].some(ext => report.fileName.toLowerCase().endsWith("." + ext));
  const isAudio = report.fileType.toLowerCase().startsWith("audio/") || ["mp3", "wav", "ogg", "mpeg", "m4a"].some(ext => report.fileName.toLowerCase().endsWith("." + ext));

  // Copy shareable link
  const handleCopyLink = () => {
    const shareUrl = `${window.location.origin}/reports/${report.id}`;
    navigator.clipboard.writeText(shareUrl).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  // Export CSV Data
  const handleExportCSV = () => {
    const rows = [
      ["Report ID", report.id],
      ["File Name", report.fileName],
      ["File Type", report.fileType],
      ["File Size (Bytes)", report.fileSize],
      ["Word Count", report.wordCount],
      ["AI Probability (%)", report.aiProbability],
      ["Human Probability (%)", report.humanProbability],
      ["Confidence Score (%)", report.confidenceScore],
      ["Risk Assessment", report.riskLevel],
      ["Complexity Score (0-100)", report.readability.complexityScore],
      ["Readability Category", report.readability.readabilityLevel],
      ["Vocabulary Variety Score", report.readability.vocabularyDiversity],
      ["Originality Rating", report.patterns.originalityScore],
      ["Predictability Entropy", report.patterns.predictabilityScore],
      ["Repetitiveness Rating", report.patterns.repetitiveness],
      ["Estimated Generator Tool", report.metadata?.generatorTool || "Classifier"],
      ["Classification Timestamp", report.createdAt]
    ];

    const csvContent = "data:text/csv;charset=utf-8," 
      + rows.map(e => e.map(val => `"${val}"`).join(",")).join("\n");
    
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `authentiai_report_${report.id}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Trigger standard formatted printing
  const handlePrint = () => {
    window.print();
  };

  const selectedHighlight = report.highlights?.find(h => h.id === activeHighlight);

  return (
    <div className="mx-auto max-w-7xl px-4 py-12 space-y-8" id="report-view-root">
      
      {/* Action Header bar */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 border-b border-gray-900 pb-6 print:hidden">
        <div className="space-y-1">
          <span className="text-[10px] font-mono tracking-widest text-cyan-400 font-bold uppercase">Classification Audit Active</span>
          <h1 className="text-2xl font-extrabold text-white tracking-tight flex items-center space-x-2">
            <span>Report Metrics Dashboard</span>
          </h1>
          <p className="text-xs text-gray-500 truncate max-w-md">Reference ID: {report.id} &bull; Loaded: {report.fileName}</p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Print button */}
          <button
            onClick={handlePrint}
            className="flex items-center space-x-1.5 rounded-lg border border-gray-800 bg-gray-900 hover:bg-gray-800 text-gray-300 py-2 px-3.5 text-xs font-semibold select-none transition-colors"
          >
            <Printer className="h-4 w-4 text-gray-400" />
            <span>Print friendly</span>
          </button>

          {/* Copy Share Link */}
          <button
            onClick={handleCopyLink}
            className="flex items-center space-x-1.5 rounded-lg border border-gray-800 bg-gray-900 hover:bg-gray-800 text-gray-300 py-2 px-3.5 text-xs font-semibold select-none transition-colors"
          >
            <Share2 className="h-4 w-4 text-gray-400" />
            <span>{copied ? "Copied Link!" : "Share Analysis"}</span>
          </button>

          {/* Export CSV Data */}
          <button
            onClick={handleExportCSV}
            className="flex items-center space-x-1.5 rounded-lg border border-gray-800 bg-gray-900 hover:bg-gray-800 text-gray-300 py-2 px-3.5 text-xs font-semibold select-none transition-colors"
          >
            <Download className="h-4 w-4 text-gray-400" />
            <span>Export CSV</span>
          </button>

          {/* Close / scan new */}
          <button
            onClick={onClose}
            className="flex items-center space-x-1 border border-cyan-800 hover:border-cyan-700 bg-cyan-950/30 hover:bg-cyan-950/50 text-cyan-300 py-2 px-4 rounded-lg text-xs font-bold"
          >
            <span>Scan New File</span>
          </button>
        </div>
      </div>

      {/* Grid of Main statistics (AIvsHuman summary) */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-stretch">
        
        {/* Gauge Card: left Column */}
        <div className="md:col-span-4 rounded-2xl border border-gray-900 bg-gray-950/40 p-6 flex flex-col justify-between relative overflow-hidden">
          <div className="space-y-2">
            <h3 className="text-sm font-bold text-white uppercase tracking-wide">Machine Coefficient</h3>
            <p className="text-xs text-gray-500 leading-relaxed font-normal">Mathematical classification estimate of language models elements.</p>
          </div>

          {/* Radial circular SVG gauge chart */}
          <div className="my-6 relative flex justify-center items-center">
            <svg className="w-52 h-52 transform -rotate-90">
              {/* Outer track circle */}
              <circle
                cx="104"
                cy="104"
                r="84"
                strokeWidth="12"
                stroke="#111827"
                fill="transparent"
              />
              {/* Active animated radial bar */}
              <circle
                cx="104"
                cy="104"
                r="84"
                strokeWidth="12"
                strokeDasharray={2 * Math.PI * 84}
                strokeDashoffset={2 * Math.PI * 84 * (1 - report.aiProbability / 100)}
                strokeLinecap="round"
                stroke="url(#aiProgressGradient)"
                fill="transparent"
                style={{ transition: "stroke-dashoffset 1s cubic-bezier(0.4, 0, 0.2, 1)" }}
              />
              <defs>
                <linearGradient id="aiProgressGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#22d3ee" />
                  <stop offset="50%" stopColor="#3b82f6" />
                  <stop offset="100%" stopColor="#6366f1" />
                </linearGradient>
              </defs>
            </svg>

            {/* Central Score readout */}
            <div className="absolute text-center">
              <span className="text-5xl font-black font-mono tracking-tighter text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-indigo-400">
                {report.aiProbability}%
              </span>
              <div className="text-[10px] font-mono tracking-widest text-gray-400 uppercase mt-1">AI PROBABILITY</div>
            </div>
          </div>

          <div className="flex justify-between items-center text-xs font-mono border-t border-gray-900 pt-5">
            <div>
              <span className="text-gray-500 block">HUMAN AUTOGRAPH</span>
              <span className="text-white font-bold text-sm mt-0.5 block">{report.humanProbability}%</span>
            </div>
            <div className="text-right">
              <span className="text-gray-500 block">CERTAINTY STAT</span>
              <span className="text-cyan-400 font-bold text-sm mt-0.5 block">{report.confidenceScore}%</span>
            </div>
          </div>
        </div>

        {/* Audit Indicators details card: Middle Column */}
        <div className="md:col-span-8 rounded-2xl border border-gray-900 bg-gray-950/40 p-6 flex flex-col justify-between">
          
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b border-gray-900 pb-4">
              <div>
                <h3 className="text-sm font-bold text-white uppercase tracking-wide">Forensic Verdict</h3>
                <p className="text-xs text-gray-500 mt-1">Linguistic risk evaluation profile metrics</p>
              </div>
              <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-bold tracking-wider uppercase ${risk.badge}`}>
                {report.riskLevel} Risk
              </span>
            </div>

            {/* In-depth metrics bar graphs (SVG representations) */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 py-2">
              <div className="space-y-1 bg-gray-900/40 border border-gray-850 p-3.5 rounded-xl">
                <div className="flex justify-between text-xs font-mono">
                  <span className="text-gray-400">Burstiness Variance</span>
                  <span className="text-white font-bold">{report.readability.sentenceStructureScore}%</span>
                </div>
                <div className="h-1 bg-gray-950 rounded-full overflow-hidden">
                  <div className="h-full bg-cyan-400 rounded-full" style={{ width: `${report.readability.sentenceStructureScore}%` }}></div>
                </div>
                <span className="text-[9px] text-gray-500 block pt-1">Uniform vs dynamic layouts. Higher is better.</span>
              </div>

              <div className="space-y-1 bg-gray-900/40 border border-gray-850 p-3.5 rounded-xl">
                <div className="flex justify-between text-xs font-mono">
                  <span className="text-gray-400">Lexical Diversity</span>
                  <span className="text-white font-bold">{report.readability.vocabularyDiversity}%</span>
                </div>
                <div className="h-1 bg-gray-950 rounded-full overflow-hidden">
                  <div className="h-full bg-indigo-500 rounded-full" style={{ width: `${report.readability.vocabularyDiversity}%` }}></div>
                </div>
                <span className="text-[9px] text-gray-500 block pt-1">Vocabulary range variation parameter.</span>
              </div>

              <div className="space-y-1 bg-gray-900/40 border border-gray-850 p-3.5 rounded-xl">
                <div className="flex justify-between text-xs font-mono">
                  <span className="text-gray-400">Originality Score</span>
                  <span className="text-white font-bold">{report.patterns.originalityScore}%</span>
                </div>
                <div className="h-1 bg-gray-950 rounded-full overflow-hidden">
                  <div className="h-full bg-blue-500 rounded-full" style={{ width: `${report.patterns.originalityScore}%` }}></div>
                </div>
                <span className="text-[9px] text-gray-500 block pt-1">Uniqueness probability profile.</span>
              </div>
            </div>

            {/* Explanation */}
            <div className="rounded-xl border border-gray-950 bg-gray-950 p-5 space-y-1">
              <div className="text-xs font-mono font-bold text-gray-400 uppercase">Analysis Findings Overview</div>
              <p className="text-xs text-gray-300 leading-relaxed font-normal">{report.detailedExplanation}</p>
            </div>
          </div>

          {/* Quick info parameters */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 border-t border-gray-900 pt-5 text-xs font-mono mt-4">
            <div>
              <span className="text-gray-500 block uppercase">Word count</span>
              <span className="text-white font-bold block mt-0.5">{report.wordCount} words</span>
            </div>
            <div>
              <span className="text-gray-500 block uppercase">Readability Index</span>
              <span className="text-white font-bold block mt-0.5">{report.readability.readabilityLevel}</span>
            </div>
            <div>
              <span className="text-gray-500 block uppercase">Estimated Source</span>
              <span className="text-cyan-400 font-bold block mt-0.5">{report.metadata?.generatorTool || "Automated Pattern"}</span>
            </div>
            <div>
              <span className="text-gray-500 block uppercase">Complexity Factor</span>
              <span className="text-white font-bold block mt-0.5 font-mono">{report.readability.complexityScore}/100</span>
            </div>
          </div>

        </div>
      </div>

      {/* Media Playback / Preview Element Panel */}
      {(isImage || isAudio) && report.metadata?.filePreview && (
        <div className="rounded-2xl border border-gray-900 bg-gray-950/40 p-6 space-y-4">
          <div className="flex items-center space-x-2 border-b border-gray-900 pb-3">
            <span className="text-[10px] font-mono tracking-widest text-cyan-400 font-bold uppercase">Media forensic buffer active</span>
            <div className="h-1.5 w-1.5 rounded-full bg-red-500 animate-pulse" />
          </div>
          
          <div className="flex flex-col items-center justify-center py-4 bg-gray-950/80 rounded-xl border border-gray-900/60 p-4">
            {isImage ? (
              <div className="max-w-xl w-full">
                <img 
                  src={report.metadata.filePreview} 
                  className="rounded-xl border border-gray-800 max-h-96 object-contain mx-auto bg-black shadow-2xl" 
                  alt="Forensic capture preview" 
                  referrerPolicy="no-referrer"
                />
                <p className="text-center text-[10px] text-gray-400 font-mono mt-3 uppercase tracking-wider">Visual spectrum mapping target: {report.fileName}</p>
              </div>
            ) : (
              <div className="w-full max-w-lg space-y-4">
                <div className="flex items-center space-x-4 p-4 rounded-xl bg-gray-900/40 border border-gray-850">
                  <div className="h-12 w-12 rounded-xl bg-indigo-950/40 border border-indigo-500/20 text-indigo-400 flex items-center justify-center text-xl animate-pulse">
                    🎙️
                  </div>
                  <div>
                    <span className="text-xs font-bold text-white block truncate">{report.fileName}</span>
                    <span className="text-[9px] text-gray-500 font-mono uppercase mt-0.5 block">{report.fileType || "Acoustic Stream Capture"}</span>
                  </div>
                </div>
                
                {/* Real-time native HTML5 audio controller */}
                <audio 
                  controls 
                  src={report.metadata.filePreview} 
                  className="w-full" 
                />
                <p className="text-center text-[10px] text-gray-400 font-mono uppercase tracking-wider">Acoustic signature mapping target: {report.fileName}</p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Two-Column split for HIGHLIGHTS (suspicious areas inspector) and PATTERNS */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Passages Inspector (Highlights): Left 7-Cols */}
        <div className="lg:col-span-8 rounded-2xl border border-gray-900 bg-gray-950/40 p-6 space-y-4">
          <div className="space-y-1">
            <h3 className="text-sm font-bold text-white uppercase tracking-wide">Suspicious Passages Inspector</h3>
            <p className="text-xs text-gray-500 leading-relaxed">Click a sentence within the classification blocks below to inspect is forensic properties.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-12 gap-6 pt-2 items-start">
            
            {/* List of Highlight buttons */}
            <div className="md:col-span-5 space-y-2">
              {report.highlights.map((item) => (
                <button
                  key={item.id}
                  onClick={() => setActiveHighlight(item.id)}
                  className={`w-full text-left p-3.5 rounded-xl border text-xs leading-relaxed transition-all flex justify-between items-start cursor-pointer group ${
                    activeHighlight === item.id
                      ? "bg-cyan-950/20 border-cyan-500/50 text-white"
                      : "bg-gray-900/20 border-gray-850 text-gray-400 hover:border-gray-800 hover:bg-gray-900/30"
                  }`}
                >
                  <span className="truncate pr-4 leading-normal font-medium">{item.text}</span>
                  <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded leading-none shrink-0 border uppercase font-bold ${
                    item.isSuspicious 
                      ? "bg-red-950/20 text-red-400 border-red-900/30" 
                      : "bg-green-950/20 text-green-400 border-green-900/30"
                  }`}>
                    {item.isSuspicious ? `${item.score}% AI` : "Human"}
                  </span>
                </button>
              ))}
            </div>

            {/* Inspector Reading detail pane */}
            <div className="md:col-span-7 rounded-2xl bg-gray-900/30 border border-gray-850 p-5 space-y-4 min-h-[160px] flex flex-col justify-between">
              {selectedHighlight ? (
                <>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between border-b border-gray-850 pb-2.5">
                      <span className="text-[10px] font-mono uppercase tracking-widest text-cyan-400 font-bold">Linguistic Diagnosis</span>
                      <span className={`text-xs font-bold font-mono tracking-wide ${selectedHighlight.isSuspicious ? "text-red-400" : "text-green-400"}`}>
                        {selectedHighlight.isSuspicious ? "Algorithmic Match Indicator" : "Organic Human Markings"}
                      </span>
                    </div>

                    <p className="text-xs text-white leading-relaxed font-semibold italic">
                      "{selectedHighlight.text}"
                    </p>

                    <p className="text-xs text-gray-400 leading-relaxed font-normal">
                      <strong className="text-gray-300">Linguistic feedback:</strong> {selectedHighlight.reason || "Fragment shows low burstiness parameters and typical machine vocabulary selections."}
                    </p>
                  </div>

                  <div className="flex justify-between items-center text-[10px] font-mono text-gray-500 pt-4 border-t border-gray-850/50 mt-4 h-6">
                    <span>SECTOR ID: {selectedHighlight.id}</span>
                    <span>PROBABILITY MATCH: {selectedHighlight.score}%</span>
                  </div>
                </>
              ) : (
                <div className="text-center text-gray-500 h-full flex items-center justify-center p-6 text-xs font-normal leading-normal">
                  Select a forensic passage on the left side to show in-depth classifier notes.
                </div>
              )}
            </div>

          </div>
        </div>

        {/* Pattern Analytics Details Panel: Right 4-Cols */}
        <div className="lg:col-span-4 rounded-2xl border border-gray-900 bg-gray-950/40 p-6 space-y-6">
          <div className="space-y-2">
            <h3 className="text-sm font-bold text-white uppercase tracking-wide">Pattern Analysis Log</h3>
            <p className="text-xs text-gray-500 leading-relaxed">Overview of repetitive models and machine characteristics.</p>
          </div>

          <div className="space-y-4">
            {/* Repetitiveness */}
            <div className="space-y-2">
              <div className="flex justify-between text-xs">
                <span className="text-gray-400 font-medium">Linguistic Repetition</span>
                <span className="text-white font-mono font-bold">{report.patterns.repetitiveness}/100</span>
              </div>
              <div className="h-2 w-full bg-gray-900 rounded-full overflow-hidden">
                <div className="h-full bg-pink-500" style={{ width: `${report.patterns.repetitiveness}%` }}></div>
              </div>
              <p className="text-[10px] text-gray-500 leading-normal font-normal">
                LLMs recycle words and phrasing loops. Lower levels denote dynamic creative writing.
              </p>
            </div>

            {/* Predictability */}
            <div className="space-y-2 pt-2 border-t border-gray-900">
              <div className="flex justify-between text-xs">
                <span className="text-gray-400 font-medium">Predictability Coefficient</span>
                <span className="text-white font-mono font-bold">{report.patterns.predictabilityScore}/100</span>
              </div>
              <div className="h-2 w-full bg-gray-900 rounded-full overflow-hidden">
                <div className="h-full bg-purple-500" style={{ width: `${report.patterns.predictabilityScore}%` }}></div>
              </div>
              <p className="text-[10px] text-gray-500 leading-normal font-normal">
                Probability score of sequences mapping following words. High denotes robotic structuring.
              </p>
            </div>

            {/* Code comments if they exist */}
            {report.patterns.codeStyleIndicators && (
              <div className="rounded-xl border border-blue-900/30 bg-blue-950/10 p-4 space-y-1 mt-4">
                <div className="text-[10px] font-mono font-bold text-blue-400 uppercase">Code Structures Highlight</div>
                <p className="text-[11px] text-blue-300 font-medium leading-relaxed">{report.patterns.codeStyleIndicators}</p>
              </div>
            )}
          </div>
        </div>

      </div>

      {/* Corporate Footnote and Disclaimer */}
      <div className="border-t border-gray-900 pt-6 text-[11px] text-gray-650 flex flex-col md:flex-row md:items-center md:justify-between gap-4 font-mono leading-relaxed">
        <span>SECURITY LEVEL: JWT-AUTHENTICATED FORENSIC REPORT SHA-256 SYSTEM</span>
        <span className="text-right">DISCLAIMER: Classifications are statistical. Results do not guarantee creator identity.</span>
      </div>
    </div>
  );
}
