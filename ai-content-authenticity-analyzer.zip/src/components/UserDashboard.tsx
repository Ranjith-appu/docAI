import React from "react";
import { 
  History, Calendar, FileText, Check, Sparkles, User, 
  Trash2, ArrowUpRight, BarChart3, GraduationCap, ShieldCheck 
} from "lucide-react";
import { User as UserType, AnalysisReport } from "../types";

interface UserDashboardProps {
  user: UserType;
  reports: AnalysisReport[];
  onSelectReport: (report: AnalysisReport) => void;
  onDeleteReport: (reportId: string) => void;
  onTogglePlan: () => void;
  onUpdateName: (name: string) => void;
}

export default function UserDashboard({ 
  user, reports, onSelectReport, onDeleteReport, onTogglePlan, onUpdateName 
}: UserDashboardProps) {

  const totalScans = reports.length;
  const aiDominant = reports.filter(r => r.aiProbability >= 50).length;
  const humanDominant = reports.filter(r => r.aiProbability < 50).length;

  const averageProbability = totalScans > 0 
    ? Math.round(reports.reduce((acc, r) => acc + r.aiProbability, 0) / totalScans)
    : 0;

  return (
    <div className="mx-auto max-w-7xl px-4 py-12 space-y-10">
      
      {/* Dashboard Header Banner */}
      <div className="rounded-2xl border border-gray-900 bg-gradient-to-tr from-gray-950 via-gray-900/40 to-cyan-950/10 p-8 flex flex-col md:flex-row justify-between items-start md:items-center gap-6 relative overflow-hidden">
        <div className="space-y-2 relative z-10">
          <div className="inline-flex items-center space-x-1 rounded-md bg-cyan-950/40 text-cyan-400 border border-cyan-500/10 px-2.5 py-0.5 text-xs font-mono font-bold uppercase">
            Account Workspace
          </div>
          <h1 className="text-2xl font-black text-white tracking-tight">Welcome Back, {user.name}</h1>
          <p className="text-xs text-gray-400 max-w-lg leading-relaxed font-normal">
            Manage your linguistic auditing dashboard, inspect past verification sessions, or adjust security configurations.
          </p>
        </div>

        {/* Dynamic usage progress stats */}
        <div className="flex flex-col space-y-2 w-full md:w-auto shrink-0 relative z-10 bg-gray-950/40 backdrop-blur-xl border border-gray-850 p-5 rounded-xl">
          <div className="flex justify-between text-xs font-mono">
            <span className="text-gray-400">DAILY ATTEMPTS USED</span>
            <span className="text-cyan-400 font-bold">{user.subscriptionPlan === 'premium' ? 'Unlimited' : `${user.analysesToday}/5`}</span>
          </div>

          <div className="h-2 w-full md:w-48 bg-gray-900 rounded-full overflow-hidden border border-gray-850">
            {user.subscriptionPlan === 'premium' ? (
              <div className="h-full bg-gradient-to-r from-cyan-400 to-indigo-500 rounded-full w-full" />
            ) : (
              <div 
                className="h-full bg-gradient-to-r from-cyan-400 to-indigo-500 rounded-full transition-all duration-300"
                style={{ width: `${(user.analysesToday / 5) * 100}%` }}
              />
            )}
          </div>
          <span className="text-[9px] text-gray-500 block leading-none pt-1 uppercase font-mono tracking-wider">
            {user.subscriptionPlan === 'premium' ? "Premium Plan Authorized" : "Resets every 24 hours"}
          </span>
        </div>
      </div>

      {/* Aggregate Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-6">
        {/* Metric 1 */}
        <div className="rounded-xl border border-gray-900 bg-gray-950/40 p-5 space-y-3">
          <div className="text-xs font-mono text-gray-500 uppercase tracking-wider block">Aggregate Scans</div>
          <div className="flex items-baseline space-x-2">
            <span className="text-3xl font-black text-white font-mono">{totalScans}</span>
            <span className="text-xs text-gray-400">documents</span>
          </div>
        </div>

        {/* Metric 2 */}
        <div className="rounded-xl border border-gray-900 bg-gray-950/40 p-5 space-y-3">
          <div className="text-xs font-mono text-gray-500 uppercase tracking-wider block font-semibold text-red-400">AI Dominant (★)</div>
          <div className="flex items-baseline space-x-2">
            <span className="text-3xl font-black text-red-400 font-mono">{aiDominant}</span>
            <span className="text-xs text-gray-400">files</span>
          </div>
        </div>

        {/* Metric 3 */}
        <div className="rounded-xl border border-gray-900 bg-gray-950/40 p-5 space-y-3">
          <div className="text-xs font-mono text-gray-500 uppercase tracking-wider block font-semibold text-green-400">Human Autographed</div>
          <div className="flex items-baseline space-x-2">
            <span className="text-3xl font-black text-green-400 font-mono">{humanDominant}</span>
            <span className="text-xs text-gray-400">files</span>
          </div>
        </div>

        {/* Metric 4 */}
        <div className="rounded-xl border border-gray-900 bg-gray-950/40 p-5 space-y-3">
          <div className="text-xs font-mono text-gray-500 uppercase tracking-wider block">Average AI Probability</div>
          <div className="flex items-baseline space-x-2">
            <span className="text-3xl font-black text-cyan-400 font-mono">{averageProbability}%</span>
            <span className="text-xs text-gray-400">weighted certainty</span>
          </div>
        </div>
      </div>

      {/* Profile Adjustments & Plan Toggle columns row */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Historical Scans Explorer: Left 8-Cols */}
        <div className="lg:col-span-8 space-y-4">
          <div className="flex justify-between items-center border-b border-gray-900 pb-3">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center space-x-2">
              <History className="h-4.5 w-4.5 text-gray-400" />
              <span>Linguistic Analysis History</span>
            </h3>
            <span className="text-[10px] text-gray-500 font-mono">{totalScans} verified items in history</span>
          </div>

          {totalScans === 0 ? (
            <div className="rounded-2xl border border-dashed border-gray-900 bg-gray-900/10 p-12 text-center text-xs text-gray-500 space-y-1">
              <FileText className="h-8 w-8 text-gray-400 mx-auto mb-3" />
              <div className="font-bold text-gray-300">No Historical Scans Found</div>
              <p className="max-w-xs mx-auto text-gray-500 leading-relaxed font-normal">
                Files analyzed inside the Analyzer portal will be archived securely here for your auditing.
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {reports.map((report) => (
                <div
                  key={report.id}
                  className="rounded-xl border border-gray-900 bg-gray-950/20 hover:border-gray-800 hover:bg-gray-950/40 p-4 transition-all flex items-center justify-between gap-4"
                >
                  <div className="flex items-center space-x-3.5 min-w-0">
                    <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gray-900 border border-gray-850 shrink-0 text-gray-400">
                      <FileText className="h-5 w-5" />
                    </div>
                    <div className="min-w-0">
                      <span 
                        onClick={() => onSelectReport(report)}
                        className="text-xs font-bold text-white hover:text-cyan-400 hover:underline cursor-pointer block truncate"
                      >
                        {report.fileName}
                      </span>
                      <div className="flex flex-wrap items-center gap-1.5 text-[9px] text-gray-500 font-mono tracking-wide mt-1">
                        <span>{report.wordCount} words</span>
                        <span>&bull;</span>
                        <span>{(report.fileSize / 1024).toFixed(1)} KB</span>
                        <span>&bull;</span>
                        <span className="text-gray-450">{new Date(report.createdAt).toLocaleDateString()}</span>
                      </div>
                    </div>
                  </div>

                  {/* Right hand values/actions */}
                  <div className="flex items-center space-x-4 shrink-0 font-mono">
                    <div className="text-right">
                      <span className={`text-xs font-black block ${
                        report.aiProbability >= 60 ? 'text-red-400' : report.aiProbability >= 30 ? 'text-yellow-400' : 'text-green-400'
                      }`}>
                        {report.aiProbability}% AI
                      </span>
                      <span className="text-[9px] text-gray-500 uppercase block">{report.riskLevel} Risk</span>
                    </div>

                    <div className="flex items-center space-x-1 border-l border-gray-900 pl-4">
                      {/* Navigate details */}
                      <button
                        onClick={() => onSelectReport(report)}
                        title="Inspect Statistics"
                        className="flex h-8 w-8 items-center justify-center rounded-lg hover:bg-gray-900/40 text-gray-400 hover:text-cyan-400 transition-colors cursor-pointer"
                      >
                        <ArrowUpRight className="h-4 w-4" />
                      </button>

                      {/* Delete */}
                      <button
                        onClick={() => onDeleteReport(report.id)}
                        title="Eraser record log"
                        className="flex h-8 w-8 items-center justify-center rounded-lg hover:bg-red-950/20 text-gray-500 hover:text-red-400 transition-colors cursor-pointer"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Profile Details Adjustments & Plans: Right 4-Cols */}
        <div className="lg:col-span-4 space-y-6">

          {/* User Profile Form */}
          <div className="rounded-xl border border-gray-900 bg-gray-950/40 p-5 space-y-4">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center space-x-2">
              <User className="h-4 w-4 text-cyan-400" />
              <span>Identity Profile Settings</span>
            </h3>

            <div className="space-y-3.5">
              <div>
                <label className="block text-[10px] font-mono font-semibold tracking-wider uppercase text-gray-500 mb-1.5">Authorized Email</label>
                <input
                  type="text"
                  disabled
                  value={user.email}
                  className="w-full rounded-lg border border-gray-900 bg-gray-950/40 px-3 py-2 text-xs text-gray-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-[10px] font-mono font-semibold tracking-wider uppercase text-gray-500 mb-1.5">Display Name</label>
                <input
                  type="text"
                  defaultValue={user.name}
                  onChange={(e) => onUpdateName(e.target.value)}
                  className="w-full rounded-lg border border-gray-900 bg-gray-950 px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500/60 transition-colors"
                />
              </div>
            </div>
          </div>

          {/* SaaS Plan visual card inside Dashboard */}
          <div className="rounded-xl border border-gray-900 bg-gray-950/40 p-5 space-y-5">
            <div className="flex justify-between items-start">
              <div className="space-y-0.5">
                <span className="text-[10px] font-mono text-gray-500 uppercase block leading-none">Subscription Status</span>
                <span className="text-white font-bold text-sm block">{user.subscriptionPlan === 'premium' ? 'Premium Unlimited' : 'Scholar Free tier'}</span>
              </div>
              <span className={`inline-flex h-7 w-7 items-center justify-center rounded-lg bg-cyan-950/40 text-cyan-400 border border-cyan-500/20`}>
                <Sparkles className="h-4 w-4" />
              </span>
            </div>

            <div className="text-xs text-gray-400 leading-relaxed font-normal">
              {user.subscriptionPlan === 'premium' 
                ? "Excellent. You enjoy unlimited parallel document verifications, large size uploads (up to 40MB), and advanced model classification reports."
                : "Free tier accounts are constrained to 5 verification scans per day. Upgrade to unlimited to streamline large assignments or publications."
              }
            </div>

            <button
              onClick={onTogglePlan}
              className="w-full flex items-center justify-center space-x-2 rounded-lg bg-gray-900 hover:bg-gray-800 text-cyan-300 border border-gray-800 py-2.5 text-xs font-bold transition-all"
            >
              <span>{user.subscriptionPlan === 'premium' ? 'Downgrade to Free' : 'Instantly Go Premium'}</span>
            </button>
          </div>

        </div>

      </div>

    </div>
  );
}
